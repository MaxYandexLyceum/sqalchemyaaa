import datetime

from flask import Flask, render_template
from werkzeug.utils import redirect

from data import db_session
from data.db_session import global_init
from data.jobs import Jobs
from data.users import User
from forms.user import RegisterForm

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
global_init("db/scalchemy_base.db")


@app.route('/')
def index():
    db_sess = db_session.create_session()
    d = []
    for job in db_sess.query(Jobs).all():
        m = []
        m.append(job.id)
        m.append(job.job)
        for user in db_sess.query(User).filter(User.id == job.team_leader):
            m.append(user.name + " " + user.surname)
        m.append(job.work_size)
        m.append(job.collaborators)
        m.append(job.is_finished)
        d.append(m)
    return render_template('index.html', d=d)


@app.route('/register', methods=['GET', 'POST'])
def reqister():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Пароли не совпадают")
        db_sess = db_session.create_session()
        if db_sess.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Такой пользователь уже есть")
        user = User(
            surname=form.surname.data,
            age=int(form.age.data),
            position=form.position.data,
            speciality=form.speciality.data,
            name=form.name.data,
            email=form.email.data,
            address=form.address.data,
            hashed_password=form.password.data,
        )
        user.set_password(form.password.data)
        db_sess.add(user)
        db_sess.commit()
        return redirect('/register')
    return render_template('register.html', title='Регистрация', form=form)


def main():
    try:
        job = Jobs()
        job.team_leader = 1
        job.job = "deployment of residential modules 1 and 2"
        job.work_size = 15
        job.collaborators = "2, 3"
        job.start_date = datetime.datetime.now()
        job.is_finished = False

        user = User()
        user.name = "Ridley"
        user.surname = "Scott"
        user.age = 21
        user.position = "captain"
        user.speciality = "research engineer"
        user.address = "module_1"
        user.email = "scott_chief@mars.org"

        user1 = User()
        user1.name = "Ridleya"
        user1.surname = "Scotta"
        user1.age = 22
        user1.position = "captaina"
        user1.speciality = "research engineear"
        user1.address = "module_1a"
        user1.email = "dadada@ok.com"

        user2 = User()
        user2.name = "Ridleyaa"
        user2.surname = "Scottaa"
        user2.age = 22
        user2.position = "captainaa"
        user2.speciality = "research engineeara"
        user2.address = "module_1aa"
        user2.email = "aaaa@aaaaa.ru"

        user3 = User()
        user3.name = "Ridleyaa"
        user3.surname = "Scottaa"
        user3.age = 22
        user3.position = "captainaa"
        user3.speciality = "research engineeara"
        user3.address = "module_1aa"
        user3.email = "fef@aaaaa.ru"

        db_sess = db_session.create_session()
        db_sess.add(job)
        db_sess.add(user)
        db_sess.add(user1)
        db_sess.add(user2)
        db_sess.add(user3)
        db_sess.commit()
    except Exception:
        pass
    app.run()


if __name__ == '__main__':
    main()
